
//
//  OpenSearchModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "OpenSearchModel.h"

@implementation OpenSearchModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[OpenSearchData class]};
}

@end
@implementation OpenSearchData

@end





