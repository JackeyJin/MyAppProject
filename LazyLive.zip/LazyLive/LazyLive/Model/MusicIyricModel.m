//
//  MusicIyricModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "MusicIyricModel.h"

@implementation MusicIyricModel
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[MusicIyricData class]};
}

@end
@implementation MusicIyricData

@end


