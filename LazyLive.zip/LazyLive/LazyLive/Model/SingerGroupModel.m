//
//  SingerGroupModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "SingerGroupModel.h"

@implementation SingerGroupModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[SingerGroupData class]};
}

@end

@implementation SingerGroupData
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"ID":@"_id",
             @"picUrl":@"pic_url",
             @"bigPicUrl":@"big_pic_url"
             };
}

@end