//
//  NewCDMusicContentModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/9.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NewCDMusicContentModel.h"

@implementation NewCDMusicContentModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{
             @"owner":[Owner class],
             @"image":[Image class],
             @"songs":[Songs class]
             };
}

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"commentCount":@"comment_count",
             @"createdTime":@"created_time",
             @"favoriteCount":@"favorite_count",
             @"lastUpdated":@"last_updated",
             @"songCount":@"song_count",
             @"listenCount":@"listen_count",
             @"shareCount":@"share_count",
             @"songlistId":@"songlist_id"
             };
}
@end

@implementation Owner
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"nickName":@"nick_name",
             @"userId":@"user_id",
             @"coverPic":@"cover_pic",
             @"portraitPic":@"portrait_pic"
             };
}
@end


@implementation Image

@end


@implementation Songs
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{
             @"mvlist":[Mvlist class],
             @"rightkey":[Rightkey class],
             @"singers":[Singers class],
             @"auditionlist":[Auditionlist class],
             @"urllist":[Urllist class]
             };
}
@end


@implementation Rightkey
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{
             @"songrights":[Songrights class]
             };
}
@end


@implementation Songrights

@end


@implementation Urllist

@end


@implementation Singers

@end


@implementation Auditionlist
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"ID":@"id"
             };
}
@end


@implementation Mvlist

@end


