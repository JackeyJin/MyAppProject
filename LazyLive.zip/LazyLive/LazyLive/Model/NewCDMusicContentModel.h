//
//  NewCDMusicContentModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/9.
//  Copyright © 2016年 tarena. All rights reserved.
//新专辑内容：歌手,歌曲信息,歌曲地址,mv
//http://api.songlist.ttpod.com/songlists/308562869

#import <Foundation/Foundation.h>

@class Owner,Image,Songs,Rightkey,Songrights,Urllist,Singers,Auditionlist,Mvlist;
@interface NewCDMusicContentModel : NSObject

@property (nonatomic, assign) BOOL favorite;
//comment_count
@property (nonatomic, copy) NSString *commentCount;
//created_time
@property (nonatomic, assign) long long createdTime;

@property (nonatomic, assign) NSInteger version;
//favorite_count
@property (nonatomic, copy) NSString *favoriteCount;

@property (nonatomic, strong) Owner *owner;
//last_updated
@property (nonatomic, assign) long long lastUpdated;

@property (nonatomic, strong) NSArray *tags;

@property (nonatomic, copy) NSString *desc;

@property (nonatomic, copy) NSString *title;
//song_count
@property (nonatomic, assign) NSInteger songCount;

@property (nonatomic, strong) Image *image;
//listen_count
@property (nonatomic, assign) NSInteger listenCount;

@property (nonatomic, strong) NSArray<Songs *> *songs;
//share_count
@property (nonatomic, assign) NSInteger shareCount;

@property (nonatomic, assign) NSInteger status;
//songlist_id
@property (nonatomic, assign) NSInteger songlistId;

@end
@interface Owner : NSObject
//nick_name
@property (nonatomic, copy) NSString *nickName;

@property (nonatomic, assign) NSInteger identity;
//user_id
@property (nonatomic, assign) NSInteger userId;
//cover_pic
@property (nonatomic, copy) NSString *coverPic;

@property (nonatomic, copy) NSString *tag;
//portrait_pic
@property (nonatomic, copy) NSString *portraitPic;

@end

@interface Image : NSObject

@property (nonatomic, copy) NSString *pic;

@property (nonatomic, assign) NSInteger source;

@end

@interface Songs : NSObject

@property (nonatomic, assign) NSInteger audit;

@property (nonatomic, copy) NSString *alias;

@property (nonatomic, assign) NSInteger isExclusive;

@property (nonatomic, assign) NSInteger mvBulletCount;

@property (nonatomic, strong) NSArray<Mvlist *> *mvList;

@property (nonatomic, copy) NSString *level;

@property (nonatomic, assign) NSInteger lang;

@property (nonatomic, copy) NSString *outList;

@property (nonatomic, assign) NSInteger commentCount;

@property (nonatomic, assign) NSInteger producer;

@property (nonatomic, copy) NSString *albumName;

@property (nonatomic, assign) NSInteger operType;

@property (nonatomic, strong) Rightkey *rightKey;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, assign) NSInteger favorites;

@property (nonatomic, assign) NSInteger librettistId;

@property (nonatomic, assign) NSInteger songId;

@property (nonatomic, copy) NSString *librettistName;

@property (nonatomic, copy) NSString *composerName;

@property (nonatomic, copy) NSString *singerName;

@property (nonatomic, copy) NSString *llList;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *remarks;

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, assign) NSInteger singerSFlag;

@property (nonatomic, assign) NSInteger outFlag;

@property (nonatomic, strong) NSArray<Singers *> *singers;

@property (nonatomic, assign) NSInteger composerId;

@property (nonatomic, copy) NSString *tags;

@property (nonatomic, assign) NSInteger mvPickCount;

@property (nonatomic, assign) BOOL firstHit;

@property (nonatomic, assign) NSInteger singerId;

@property (nonatomic, assign) NSInteger originalId;

@property (nonatomic, assign) NSInteger albumId;

@property (nonatomic, strong) NSArray<Auditionlist *> *auditionList;

@property (nonatomic, assign) NSInteger publisher;

@property (nonatomic, strong) NSArray<Urllist *> *urlList;

@property (nonatomic, assign) NSInteger listenCount;

@property (nonatomic, strong) NSArray *outLinks;

@property (nonatomic, assign) NSInteger releaseYear;

@property (nonatomic, assign) NSInteger riskRank;

@end

@interface Rightkey : NSObject

@property (nonatomic, strong) NSArray *musicPackage;

@property (nonatomic, strong) NSArray *albumPackage;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, assign) NSInteger paymentUnite;

@property (nonatomic, assign) NSInteger loginStatus;

@property (nonatomic, copy) NSString *vipFree;

@property (nonatomic, strong) NSArray<Songrights *> *songRights;

@property (nonatomic, copy) NSString *promotionPackage;

@property (nonatomic, assign) NSInteger orderType;

@end

@interface Songrights : NSObject

@property (nonatomic, assign) BOOL downFlag;

@property (nonatomic, assign) BOOL listenBuyFlag;

@property (nonatomic, assign) NSInteger bitRate;

@property (nonatomic, assign) NSInteger downloadRightFlag;

@property (nonatomic, assign) NSInteger auditionRightFlag;

@property (nonatomic, assign) BOOL listenFlag;

@property (nonatomic, assign) BOOL downBuyFlag;

@end

@interface Urllist : NSObject

@property (nonatomic, assign) NSInteger size;

@property (nonatomic, copy) NSString *typeDescription;

@property (nonatomic, assign) NSInteger bitRate;

@property (nonatomic, copy) NSString *suffix;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, assign) NSInteger duration;

@end

@interface Singers : NSObject

@property (nonatomic, copy) NSString *singerName;

@property (nonatomic, assign) NSInteger singerSFlag;

@property (nonatomic, assign) NSInteger singerId;

@property (nonatomic, assign) NSInteger shopId;

@end

@interface Auditionlist : NSObject

@property (nonatomic, assign) NSInteger size;

@property (nonatomic, copy) NSString *typeDescription;

@property (nonatomic, assign) NSInteger bitRate;

@property (nonatomic, copy) NSString *suffix;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, assign) NSInteger duration;

@end

@interface Mvlist : NSObject
//id
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *typeDescription;

@property (nonatomic, copy) NSString *suffix;

@property (nonatomic, assign) NSInteger songId;

@property (nonatomic, assign) NSInteger videoId;

@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, copy) NSString *url;

@property (nonatomic, assign) NSInteger vertical;

@property (nonatomic, copy) NSString *path;

@property (nonatomic, assign) NSInteger size;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, assign) NSInteger horizontal;

@property (nonatomic, assign) NSInteger durationMilliSecond;

@property (nonatomic, assign) NSInteger duration;

@property (nonatomic, assign) NSInteger bitRate;

@end

