//
//  OpenSearchModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//http://so.ard.iyyin.com/sug/billboard
//热搜索前几位：歌曲与歌手

#import <Foundation/Foundation.h>

@class OpenSearchData;
@interface OpenSearchModel : NSObject

@property (nonatomic, strong) NSArray<OpenSearchData *> *data;

@property (nonatomic, assign) NSInteger code;

@end
@interface OpenSearchData : NSObject

@property (nonatomic, assign) NSInteger hit;

@property (nonatomic, assign) NSInteger score;

@property (nonatomic, copy) NSString *val;

@property (nonatomic, assign) NSInteger hot;

@end

