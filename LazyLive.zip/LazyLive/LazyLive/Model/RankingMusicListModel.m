//
//  RankingMusicListModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "RankingMusicListModel.h"

@implementation RankingMusicListModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[RankingMusicListData class]};
}

@end

@implementation RankingMusicListData
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"SongList":[Songlist class]};
}
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"ID":@"_id",
             @"picUrl":@"pic_url",
             @"bigPicUrl":@"big_pic_url"
             };
}
@end


@implementation Songlist

@end


