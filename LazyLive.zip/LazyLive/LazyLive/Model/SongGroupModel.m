//
//  SongGroupModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "SongGroupModel.h"

@implementation SongGroupModel
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[SongGroupData class]};
}
@end

@implementation SongGroupData

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"picUrl":@"pic_url_240_200",
             @"smallPicUrl":@"small_pic_url",
             @"songlistName":@"songlist_name",
             @"songlistId":@"songlist_id",
             @"largePicUrl":@"large_pic_url"
             };
}
@end


