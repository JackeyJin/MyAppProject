//
//  MusicLibrary.h
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//
//天天音乐

#import <Foundation/Foundation.h>


@interface MusicLibrary : NSObject

@property (nonatomic, copy) NSString *typeUrl;

@property (nonatomic, copy) NSString *typeImageName;

@property (nonatomic, copy) NSString *typeName;

@end

