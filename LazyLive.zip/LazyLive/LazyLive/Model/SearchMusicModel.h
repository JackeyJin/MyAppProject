//
//  SearchMusicModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//
/**
 搜索歌曲API：http://so.ard.iyyin.com/s/song_with_out?q={0}&page={1}&size={2}
 
 {0}=需要搜索的歌曲或歌手
 
 {1}=查询的页码数
 
 {2}=当前页的返回数量
 */
//天天音乐的查找音乐q=查找歌手或歌名
//http://search.dongting.com/song/search/old?q=%E6%88%91%E4%BB%AC%E9%83%BD%E4%B8%80%E6%A0%B7%20(Live)&page=1&size=3
#import <Foundation/Foundation.h>
//Url_List,Audition_List
@class SearchData,UrlList,AuditionList;
@interface SearchMusicModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, assign) NSInteger pages;

@property (nonatomic, assign) NSInteger rows;

@property (nonatomic, strong) NSArray<SearchData *> *data;

@end

@interface SearchData : NSObject
//album_id
@property (nonatomic, assign) NSInteger albumId;
//song_id
@property (nonatomic, assign) NSInteger songId;
//singer_name
@property (nonatomic, copy) NSString *singerName;
//song_name
@property (nonatomic, copy) NSString *songName;
//audition_list
@property (nonatomic, strong) NSArray<AuditionList *> *auditionList;
//url_list
@property (nonatomic, strong) NSArray<UrlList *> *urlList;
//album_name
@property (nonatomic, copy) NSString *albumName;

@property (nonatomic, assign) NSInteger vip;
//pick_count
@property (nonatomic, assign) NSInteger pickCount;
//singer_id
@property (nonatomic, assign) NSInteger singerId;
//artist_flag
@property (nonatomic, assign) NSInteger artistFlag;

@end
//Url_List
@interface UrlList : NSObject

@property (nonatomic, copy) NSString *suffix;

@property (nonatomic, assign) NSInteger bitRate;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *typeDescription;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, copy) NSString *url;

@end

@interface AuditionList : NSObject

@property (nonatomic, copy) NSString *suffix;

@property (nonatomic, assign) NSInteger bitRate;

@property (nonatomic, copy) NSString *size;

@property (nonatomic, copy) NSString *duration;

@property (nonatomic, copy) NSString *typeDescription;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, copy) NSString *url;

@end

