//
//  RankingMusicListModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//排行榜
//http://v1.ard.tj.itlily.com/ttpod?a=getnewttpod&id=281
//获取数据data中的ID值2406//第一个最美和声一般没有资源地址，而下面的🈶️
//http://api.dongting.com/channel/ranklist/2406/songs?page=1
////对于第一部找不到资源通过查找音乐名name来找到资源(SearchMusicModel)
////http://search.dongting.com/song/search/old?q=%E6%88%91%E4%BB%AC%E9%83%BD%E4%B8%80%E6%A0%B7%20(Live)&page=1&size=3
#import <Foundation/Foundation.h>

@class RankingMusicListData,Songlist;
@interface RankingMusicListModel : NSObject

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray<RankingMusicListData *> *data;

@property (nonatomic, assign) NSInteger code;

@end

@interface RankingMusicListData : NSObject

@property (nonatomic, assign) NSInteger style;

@property (nonatomic, copy) NSString *details;
//id
@property (nonatomic, assign) NSInteger ID;
//pic_url
@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *time;
//big_pic_url
@property (nonatomic, copy) NSString *bigPicUrl;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, strong) NSArray<Songlist *> *songlist;

@end

@interface Songlist : NSObject

@property (nonatomic, copy) NSString *singerName;

@property (nonatomic, copy) NSString *songName;

@end

