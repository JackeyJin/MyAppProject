//
//  NewCDMusic.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NewCDMusic.h"

@implementation NewCDMusic
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[NewCDData class]};
}
@end

@implementation NewCDData
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"msgId":@"msg_id",
             @"ID":@"_id",
             @"picUrl":@"pic_url"
             };
}
@end


