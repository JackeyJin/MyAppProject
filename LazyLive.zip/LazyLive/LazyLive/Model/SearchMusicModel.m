//
//  SearchMusicModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "SearchMusicModel.h"

@implementation SearchMusicModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[SearchData class]};
}

@end

@implementation SearchData
+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"auditionList":[AuditionList class],@"urlList":[UrlList class]};
}

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"albumId": @"album_id",
             @"songId":@"song_id",
             @"singerName":@"singer_name",
             @"songName":@"song_name",
             @"albumName":@"album_name",
             @"pickCount":@"pick_count",
             @"singerId":@"singer_id",
             @"artistFlag":@"artist_flag"
             };
}



@end


@implementation UrlList

@end


@implementation AuditionList

@end


