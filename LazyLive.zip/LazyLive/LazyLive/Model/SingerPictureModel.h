//
//  SingerPictureModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//
//天天音乐歌手图片

#import <Foundation/Foundation.h>

@class SingerData;
@interface SingerPictureModel : NSObject

@property (nonatomic, strong) SingerData *data;

@property (nonatomic, assign) NSInteger code;

@end
@interface SingerData : NSObject

@property (nonatomic, copy) NSString *singerPic;

@end

