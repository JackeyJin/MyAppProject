//
//  MusicIyricModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
/**歌词API：http://lp.music.ttpod.com/lrc/down?lrcid=&artist={2}&title={1}&song_id={0}
 
 {0}=歌曲ID
 
 {1}=歌曲名
 
 {2}=歌手名*/
//http://lp.music.ttpod.com/lrc/down?lrcid=&artist=%E5%91%A8%E6%9D%B0%E4%BC%A6&title=%E6%89%8B%E5%86%99%E7%9A%84%E4%BB%8E%E5%89%8D(Live)&song_id=29681418
//天天音乐歌词

#import <Foundation/Foundation.h>

@class MusicIyricData;
@interface MusicIyricModel : NSObject

@property (nonatomic, strong) MusicIyricData *data;

@property (nonatomic, assign) NSInteger code;

@end

@interface MusicIyricData : NSObject

@property (nonatomic, copy) NSString *lrc;

@end

