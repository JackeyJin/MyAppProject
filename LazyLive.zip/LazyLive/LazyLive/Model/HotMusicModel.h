//
//  HotMusicModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//http://api.dongting.com/frontpage/frontpage
//热听有音乐广告和实时更新
#import <Foundation/Foundation.h>

@class HotMusicData,HotMusicAction,SecondData,SecondAction;
@interface HotMusicModel : NSObject

@property (nonatomic, assign) long long version;

@property (nonatomic, strong) NSArray<HotMusicData *> *data;

@end
@interface HotMusicData : NSObject

@property (nonatomic, strong) HotMusicAction *action;

@property (nonatomic, assign) NSInteger style;
//id
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, strong) NSArray<SecondData *> *data;

@property (nonatomic, assign) NSInteger isNameDisplay;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *desc;

@end

@interface HotMusicAction : NSObject

@property (nonatomic, assign) NSInteger type;

@end

//Data
@interface SecondData : NSObject

@property (nonatomic, strong) SecondAction *action;
//id
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *picUrl;

@end
//Action
@interface SecondAction : NSObject

@property (nonatomic, assign) NSInteger type;

@property (nonatomic, copy) NSString *value;

@end

