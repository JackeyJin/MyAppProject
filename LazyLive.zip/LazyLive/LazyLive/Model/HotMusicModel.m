//
//  HotMusicModel.m
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "HotMusicModel.h"

@implementation HotMusicModel

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[HotMusicData class]};
}

@end

@implementation HotMusicData

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"data":[SecondData class],
             @"action":[HotMusicAction class]
             };
}

+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"ID":@"id"
             };
}


@end

@implementation HotMusicAction


@end

@implementation SecondData

+ (NSDictionary *)modelContainerPropertyGenericClass{
    return @{@"action":[SecondAction class]};
}
+ (NSDictionary *)modelCustomPropertyMapper{
    return @{
             @"ID":@"id"
             };
}

@end

@implementation SecondAction



@end
