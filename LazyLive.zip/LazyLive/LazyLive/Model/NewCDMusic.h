//
//  NewCDMusic.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//新歌首发
//http://online.dongting.com/recomm/new_albums?page=1&size=30
//获取msg_id （308562869）
//把ID传到http://api.songlist.ttpod.com/songlists/308562869获取专辑歌曲，和下载
#import <Foundation/Foundation.h>

@class NewCDData;
@interface NewCDMusic : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, assign) NSInteger pages;

@property (nonatomic, strong) NSArray<NewCDData *> *data;

@property (nonatomic, assign) NSInteger rows;

@end

@interface NewCDData : NSObject
//msg_id
@property (nonatomic, assign) NSInteger msgId;
//_id
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *pic;
//pic_url
@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger week;

@property (nonatomic, assign) NSInteger year;

@property (nonatomic, copy) NSString *desc;

@end

