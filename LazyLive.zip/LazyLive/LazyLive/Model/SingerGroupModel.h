//
//  SingerGroupModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//http://v1.ard.tj.itlily.com/ttpod?a=getnewttpod&id=46
//歌手组获取ID值便可以通过下面获取歌手排行榜54
//http://v1.ard.tj.itlily.com/ttpod?a=getnewttpod&id=54&size=1000&page=1
#import <Foundation/Foundation.h>


@class SingerGroupData;
@interface SingerGroupModel : NSObject

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray<SingerGroupData *> *data;

@property (nonatomic, assign) NSInteger code;

@end

@interface SingerGroupData : NSObject

@property (nonatomic, assign) NSInteger style;

@property (nonatomic, copy) NSString *details;
//id
@property (nonatomic, assign) NSInteger ID;
//pic_url
@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *time;
//big_pic_url;
@property (nonatomic, copy) NSString *bigPicUrl;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) NSInteger type;

@end

