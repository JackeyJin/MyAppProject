//
//  SongGroupModel.h
//  LazyLive
//
//  Created by tarena17 on 16/4/8.
//  Copyright © 2016年 tarena. All rights reserved.
//http://fm.api.ttpod.com/channellist?image_type=240_200分类
//获取"songlist_id": 106
//http://api.dongting.com/channel/channel/106/songs?size=50&page=1
#import <Foundation/Foundation.h>

@class SongGroupData;
@interface SongGroupModel : NSObject

@property (nonatomic, assign) NSInteger code;

@property (nonatomic, strong) NSArray<SongGroupData *> *data;

@property (nonatomic, copy) NSString *msg;

@property (nonatomic, strong) NSArray *extra;

@end
@interface SongGroupData : NSObject
//pic_url_240_200
@property (nonatomic, copy) NSString *picUrl;

@property (nonatomic, copy) NSString *details;

@property (nonatomic, assign) NSInteger quantity;

@property (nonatomic, copy) NSString *parentname;
//small_pic_url
@property (nonatomic, copy) NSString *smallPicUrl;
//songlist_name
@property (nonatomic, copy) NSString *songlistName;
//songlist_id
@property (nonatomic, assign) NSInteger songlistId;
//large_pic_url
@property (nonatomic, copy) NSString *largePicUrl;

@end

