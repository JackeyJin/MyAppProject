//
//  PlistDataManager.h
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MusicLibrary.h"


@interface PlistDataManager : NSObject

+ (void)getMusiclibrary:(void(^)(NSArray<MusicLibrary *> *musics,NSError *error))completionHandler;

@end
