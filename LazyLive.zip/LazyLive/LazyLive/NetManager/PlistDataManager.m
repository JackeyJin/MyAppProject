//
//  PlistDataManager.m
//  LazyLive
//
//  Created by tarena17 on 16/4/7.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "PlistDataManager.h"
#import "NSObject+Parse.h"

@implementation PlistDataManager

+ (void)getMusiclibrary:(void (^)(NSArray<MusicLibrary *> *, NSError *))completionHandler{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSString *path = [[NSBundle mainBundle]pathForResource:@"musicType" ofType:@"plist"];
        NSArray *array = [NSArray arrayWithContentsOfFile:path];
        NSArray *musicType = [MusicLibrary parseJSON:array];
        dispatch_async(dispatch_get_main_queue(), ^{
            completionHandler(musicType,nil);
        });
    });

}

@end
